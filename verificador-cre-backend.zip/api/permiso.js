import chromium from 'chrome-aws-lambda';
import puppeteer from 'puppeteer-core';
import pRetry from 'p-retry';
import pTimeout from 'p-timeout';

const CRE_URL = process.env.CRE_URL || 'https://www.cre.gob.mx/Permisos/index.html';

// ——— util: abre navegador compatible con Vercel ———
async function launchBrowser() {
  const executablePath = await chromium.executablePath;
  return puppeteer.launch({
    args: chromium.args,
    executablePath,
    headless: chromium.headless,
    defaultViewport: { width: 1366, height: 900 }
  });
}

// ——— scraping de un solo permiso ———
async function consultarPermiso(page, permiso) {
  if (!permiso || typeof permiso !== 'string') {
    return { permiso, mensaje: 'Parámetro "permiso" inválido' };
  }

  await page.goto(CRE_URL, { waitUntil: 'domcontentloaded', timeout: 30000 });

  // Espera y limpia el input #dtFilterNumero
  await page.waitForSelector('#dtFilterNumero', { timeout: 15000 });

  // Limpiar y escribir
  await page.evaluate(() => {
    const el = document.querySelector('#dtFilterNumero');
    if (el) { el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); }
  });

  // Llenar y disparar búsqueda (la página filtra al perder foco)
  await page.type('#dtFilterNumero', permiso, { delay: 10 });
  // Dar Tab para forzar blur
  await page.keyboard.press('Tab');

  // Esperar a que la tabla se pueble
  await page.waitForSelector('table.dataTable tbody', { timeout: 15000 });

  // Dar un pequeño margen para que aplique el filtro
  await page.waitForTimeout(500);

  // Extraer filas visibles
  const filas = await page.$$eval('table.dataTable tbody tr', rows => {
    return rows
      .filter(r => r.offsetParent !== null)
      .map(r => Array.from(r.querySelectorAll('td')).map(td => td.innerText.trim()));
  });

  if (!filas || !filas.length) {
    return { permiso, mensaje: 'Permiso no encontrado o no vigente' };
  }

  // Buscar coincidencia exacta en la primera columna (número de permiso)
  let match = filas.find(cols => (cols[0] || '').toLowerCase() === permiso.toLowerCase());
  if (!match) {
    // Si no hay exacta, tomamos la primera visible como fallback
    match = filas[0];
  }

  const [perm, estatus, permisionario, alias] = match;
  const vigente = (estatus || '').toLowerCase().includes('vigente');

  return {
    permiso: perm || permiso,
    estatus: estatus || null,
    permisionario: permisionario || null,
    alias_proyecto: alias || null,
    mensaje: vigente
      ? 'Permiso vigente ante la CRE. Factura de combustible deducible ante SAT.'
      : 'Permiso no vigente o no encontrado ante la CRE. No deducible ante SAT.'
  };
}

// ——— función pública compatible con Vercel ———
export default async function handler(req, res) {
  const method = req.method || 'GET';

  try {
    if (method === 'GET') {
      const permiso = (req.query?.permiso || '').toString().trim();
      const { status, body } = await handleSingle(permiso);
      res.status(status).json(body);
      return;
    }

    if (method === 'POST') {
      const permisos = Array.isArray(req.body?.permisos) ? req.body.permisos : null;
      if (!permisos || !permisos.length) {
        res.status(400).json({ error: 'Se requiere un arreglo "permisos" en el cuerpo JSON.' });
        return;
      }
      const { status, body } = await handleBatch(permisos);
      res.status(status).json(body);
      return;
    }

    res.status(405).json({ error: 'Método no permitido' });
  } catch (err) {
    res.status(500).json({ error: 'Error inesperado', detalle: err.message });
  }
}

// Para pruebas locales usando local-dev.js
export async function handler(reqLike) {
  const method = reqLike.method || 'GET';
  if (method === 'GET') {
    const permiso = (reqLike.query?.permiso || '').toString().trim();
    return await handleSingle(permiso);
  }
  if (method === 'POST') {
    const permisos = Array.isArray(reqLike.body?.permisos) ? reqLike.body.permisos : null;
    if (!permisos || !permisos.length) {
      return { status: 400, body: { error: 'Se requiere un arreglo "permisos" en el cuerpo JSON.' } };
    }
    return await handleBatch(permisos);
  }
  return { status: 405, body: { error: 'Método no permitido' } };
}

// ——— Implementaciones con reintentos y timeouts ———
async function handleSingle(permiso) {
  if (!permiso) return { status: 400, body: { error: 'Falta el número de permiso' } };

  let browser;
  try {
    browser = await launchBrowser();
    const page = await browser.newPage();
    // Header para parecer un navegador normal
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36');

    const result = await pRetry(
      () => pTimeout(consultarPermiso(page, permiso), 45000),
      { retries: 2, minTimeout: 1000 }
    );

    await page.close();
    await browser.close();
    return { status: 200, body: result };
  } catch (e) {
    if (browser) try { await browser.close(); } catch {}
    return { status: 500, body: { error: 'Fallo en consulta', detalle: e.message } };
  }
}

async function handleBatch(permisos) {
  let browser;
  try {
    browser = await launchBrowser();
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36');

    // Secuencial para no cargar el sitio; puedes ajustar a paralelo con límite.
    const out = [];
    for (const p of permisos) {
      const r = await pRetry(
        () => pTimeout(consultarPermiso(page, String(p || '').trim()), 45000),
        { retries: 2, minTimeout: 1000 }
      );
      out.push(r);
    }

    await page.close();
    await browser.close();
    return { status: 200, body: out };
  } catch (e) {
    if (browser) try { await browser.close(); } catch {}
    return { status: 500, body: { error: 'Fallo en consulta por lote', detalle: e.message } };
  }
}