# Verificador de Permisos CRE – Backend (Vercel)

Backend **listo para producción** que verifica el estatus de un permiso del **CRE** en la página oficial
<https://www.cre.gob.mx/Permisos/index.html> usando **Puppeteer Core + chrome-aws-lambda** (compatible con Vercel).

## Endpoints

### GET `/api/permiso?permiso=PL/XXXXX/...`
- **Entrada**: `permiso` (string)
- **Salida**:
```json
{
  "permiso": "PL/...",
  "estatus": "Vigente|...",
  "permisionario": "Razón social",
  "alias_proyecto": "Alias",
  "mensaje": "Texto de ayuda"
}
```
Si no se encuentra: `{"mensaje":"Permiso no encontrado o no vigente"}`

### POST `/api/permiso`
- **Entrada** (JSON):
```json
{"permisos": ["PL/...","PL/..."]}
```
- **Salida**: arreglo de objetos como el de GET.

## Despliegue en Vercel
1. Sube este repo a GitHub.
2. Conéctalo en Vercel.
3. Deploy. Vercel detecta `api/permiso.js` como Serverless Function.

## Desarrollo local
```bash
npm i
npm run dev
# GET  -> http://localhost:3000/?permiso=CNE/PL/516/EXP/ES/2025
# POST -> curl -X POST localhost:3000 -H 'content-type: application/json' -d '{"permisos":["...","..."]}'
```

## Notas de producción
- Maneja **rate limit** en tu frontend.
- Incluye **reintentos** y **timeouts** ya implementados en el código.
- No guardes resultados sin validar (la página puede cambiar).