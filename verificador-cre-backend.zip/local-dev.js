import http from 'node:http';
import { handler } from './api/permiso.js';

const server = http.createServer(async (req, res) => {
  // Simple router: GET /?permiso=... or POST with {permisos:[...]}
  const url = new URL(req.url, 'http://localhost:3000');
  const buffers = [];
  for await (const chunk of req) buffers.push(chunk);
  const bodyStr = Buffer.concat(buffers).toString() || null;
  const method = req.method || 'GET';

  if (method === 'GET') {
    const permiso = url.searchParams.get('permiso');
    const { status, body } = await handler({ method, query: { permiso } });
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(body));
  } else if (method === 'POST') {
    let body = null;
    try { body = JSON.parse(bodyStr || '{}'); } catch {}
    const { status, body: resp } = await handler({ method, body });
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(resp));
  } else {
    res.writeHead(405, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ error: 'Método no permitido' }));
  }
});

server.listen(3000, () => console.log('Local dev on http://localhost:3000'));